# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(wasi-build src/wasi-build.cpp)
set_property(TARGET wasi-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-build lionss pthread)

add_executable(sphinx-docs src/sphinx-docs.cpp)
set_property(TARGET sphinx-docs PROPERTY CXX_STANDARD 11)
target_link_libraries(sphinx-docs lionss pthread)

add_executable(edge-case-tests src/edge-case-tests.cpp)
set_property(TARGET edge-case-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(edge-case-tests lionss pthread)

add_executable(coroutines-check src/coroutines-check.cpp)
set_property(TARGET coroutines-check PROPERTY CXX_STANDARD 11)
target_link_libraries(coroutines-check lionss pthread)

add_executable(smoke-tests src/smoke-tests.cpp)
set_property(TARGET smoke-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(smoke-tests lionss pthread)

add_executable(lockfile-check src/lockfile-check.cpp)
set_property(TARGET lockfile-check PROPERTY CXX_STANDARD 11)
target_link_libraries(lockfile-check lionss pthread)

add_executable(split-dwarf src/split-dwarf.cpp)
set_property(TARGET split-dwarf PROPERTY CXX_STANDARD 11)
target_link_libraries(split-dwarf lionss pthread)

add_executable(retry-matrix src/retry-matrix.cpp)
set_property(TARGET retry-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(retry-matrix lionss pthread)

add_executable(cache-warmup src/cache-warmup.cpp)
set_property(TARGET cache-warmup PROPERTY CXX_STANDARD 11)
target_link_libraries(cache-warmup lionss pthread)

add_executable(determinism-tests src/determinism-tests.cpp)
set_property(TARGET determinism-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(determinism-tests lionss pthread)

add_executable(dependency-graph src/dependency-graph.cpp)
set_property(TARGET dependency-graph PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-graph lionss pthread)

add_executable(simd-throughput src/simd-throughput.cpp)
set_property(TARGET simd-throughput PROPERTY CXX_STANDARD 11)
target_link_libraries(simd-throughput lionss pthread)

add_executable(constexpr-tests src/constexpr-tests.cpp)
set_property(TARGET constexpr-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(constexpr-tests lionss pthread)

add_executable(package-appimage src/package-appimage.cpp)
set_property(TARGET package-appimage PROPERTY CXX_STANDARD 11)
target_link_libraries(package-appimage lionss pthread)

add_executable(tutorial-build src/tutorial-build.cpp)
set_property(TARGET tutorial-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tutorial-build lionss pthread)

add_executable(semver-check src/semver-check.cpp)
set_property(TARGET semver-check PROPERTY CXX_STANDARD 11)
target_link_libraries(semver-check lionss pthread)

add_executable(deprecations-check src/deprecations-check.cpp)
set_property(TARGET deprecations-check PROPERTY CXX_STANDARD 11)
target_link_libraries(deprecations-check lionss pthread)

add_executable(package-rpm src/package-rpm.cpp)
set_property(TARGET package-rpm PROPERTY CXX_STANDARD 11)
target_link_libraries(package-rpm lionss pthread)

add_executable(sast-scan src/sast-scan.cpp)
set_property(TARGET sast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(sast-scan lionss pthread)

add_executable(leap-second-tests src/leap-second-tests.cpp)
set_property(TARGET leap-second-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(leap-second-tests lionss pthread)

add_executable(tvos-build src/tvos-build.cpp)
set_property(TARGET tvos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tvos-build lionss pthread)

add_executable(timezone-tests src/timezone-tests.cpp)
set_property(TARGET timezone-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timezone-tests lionss pthread)

add_executable(openbsd-build src/openbsd-build.cpp)
set_property(TARGET openbsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(openbsd-build lionss pthread)

add_executable(clang-oldest src/clang-oldest.cpp)
set_property(TARGET clang-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-oldest lionss pthread)

add_executable(false-sharing src/false-sharing.cpp)
set_property(TARGET false-sharing PROPERTY CXX_STANDARD 11)
target_link_libraries(false-sharing lionss pthread)

add_executable(ios-simulator src/ios-simulator.cpp)
set_property(TARGET ios-simulator PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-simulator lionss pthread)

add_executable(grammar-fuzz src/grammar-fuzz.cpp)
set_property(TARGET grammar-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(grammar-fuzz lionss pthread)

add_executable(acceptance-tests src/acceptance-tests.cpp)
set_property(TARGET acceptance-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(acceptance-tests lionss pthread)

add_executable(tidy-modernize src/tidy-modernize.cpp)
set_property(TARGET tidy-modernize PROPERTY CXX_STANDARD 11)
target_link_libraries(tidy-modernize lionss pthread)

add_executable(flamegraph src/flamegraph.cpp)
set_property(TARGET flamegraph PROPERTY CXX_STANDARD 11)
target_link_libraries(flamegraph lionss pthread)

