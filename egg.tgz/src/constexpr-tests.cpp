// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("constexpr tests\n", stdout);
  return lionss_run_workload("constexpr-tests");
}
