// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("simd throughput"); }
int main(){
  announce();
  return lionss_run_workload("simd-throughput");
}
