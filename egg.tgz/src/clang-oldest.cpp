// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("clang oldest"); }
int main(){
  announce();
  return lionss_run_workload("clang-oldest");
}
