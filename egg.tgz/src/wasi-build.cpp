// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("wasi build\n", stdout);
  return lionss_run_workload("wasi-build");
}
